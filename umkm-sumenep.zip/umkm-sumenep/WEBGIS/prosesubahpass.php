<?php
session_start();
include 'koneksi.php';

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
  echo "<script>alert('Silakan login terlebih dahulu.'); window.location='login.php';</script>";
  exit;
}

$password_lama = $_POST['password_lama'] ?? '';
$password_baru = $_POST['password_baru'] ?? '';
$konfirmasi    = $_POST['konfirmasi'] ?? '';

// Validasi
if ($password_baru !== $konfirmasi) {
  echo "<script>alert('Konfirmasi password tidak cocok.'); history.back();</script>";
  exit;
}

// Ambil password lama dari database
$stmt = $conn->prepare("SELECT password FROM user WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

// Versi tanpa hash:
if ($password_lama !== $data['password']) {
  echo "<script>alert('Password lama salah.'); history.back();</script>";
  exit;
}

// Update password baru
$stmt = $conn->prepare("UPDATE user SET password = ? WHERE id = ?");
$stmt->bind_param("si", $password_baru, $user_id);

if ($stmt->execute()) {
  echo "<script>alert('Password berhasil diubah.'); window.location='../index.php';</script>";
} else {
  echo "<script>alert('Gagal mengubah password.'); history.back();</script>";
}
?>
