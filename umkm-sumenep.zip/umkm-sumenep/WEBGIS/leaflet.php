<?php
include 'koneksi.php';

$lat   = $_GET['lat'] ?? '';
$lng   = $_GET['lng'] ?? '';
$nama  = $_GET['nama'] ?? '';

// Ambil semua UMKM dengan status 'aktif' untuk marker tambahan
$dataMarker = [];
$query = $conn->query("SELECT nama, sektor, latitude, longitude, status FROM umkm WHERE status = 'aktif'");
if ($query) {
  while ($row = $query->fetch_assoc()) {
    $dataMarker[] = $row;
  }
} else {
  // Optional: log error jika query gagal
  error_log("Query UMKM gagal: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Peta Lokasi UMKM <?= htmlspecialchars($nama); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Leaflet & Font Awesome -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    #map { height: 100vh; width: 100%; }
  </style>
</head>
<body>

<div id="map"></div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
  const map = L.map('map');

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  // ✅ Fungsi ikon custom berdasarkan sektor
 function getIconBySektor(sektor) {
  const icons = {
    'Perdagangan': 'marker-icon-2x-red.png',
    'Pertanian':   'marker-icon-2x-green.png',
    'Pengolahan':  'marker-icon-2x-orange.png',
    'Jasa':        'marker-icon-2x-gold.png',
    'Kerajinan':   'marker-icon-2x-violet.png',
    'Perikanan':   'marker-icon-2x-grey.png',
    'Peternakan':  'marker-icon-2x-yellow.png'
  };

  const iconFile = icons[sektor] || 'marker-icon-2x-grey.png';

  return L.icon({
    iconUrl: '../images/' + iconFile,
    shadowUrl: '../images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
}
  // ✅ Warna kecamatan untuk GeoJSON
  function getColorByKecamatan(name) {
    const colors = {
  "Ambunten": "#e41a1c", "Arjasa": "#d7191c", "Batang Batang": "#984ea3", "Batuan": "#4daf4a",
  "Batuputih": "#a6cee3", "Bluto": "#377eb8", "Dasuk": "#ff7f00", "Dungkek": "#ffff33",
  "Ganding": "#a65628", "Gapura": "#f781bf", "Gayam": "#8c564b", "Giligenting": "#fb9a99",
  "Guluk-Guluk": "#999999", "Kalianget": "#66c2a5", "Kangayan": "#bc80bd", "Kota Sumenep": "#f4a582",
  "Lenteng": "#fc8d62", "Manding": "#b2df8a", "Masalembu": "#8da0cb", "Nonggunong": "#cab2d6",
  "Pasongsongan": "#e78ac3", "Pragaan": "#a6d854", "Raas": "#ffd92f", "Rubaru": "#e5c494",
  "Sapeken": "#b3b3b3", "Saronggi": "#ffcc99", "Talango": "#c2a5cf"
};
    return colors[name] || "#cccccc";
  }

  // ✅ Tambahkan batas kecamatan
  fetch('sumenep-kecamatan.geojson')
    .then(res => res.json())
    .then(data => {
      const geoLayer = L.geoJSON(data, {
        style: f => ({
          color: "#000",
          weight: 1,
          fillColor: getColorByKecamatan(f.properties.NAME_3),
          fillOpacity: 0.5
        }),
        onEachFeature: (f, l) => {
          l.bindPopup("Kecamatan: " + f.properties.NAME_3);
        }
      }).addTo(map);

      // Pusat ke UMKM tertentu atau ke keseluruhan
      <?php if (!empty($lat) && !empty($lng)): ?>
        const lokasiUMKM = [<?= $lat ?>, <?= $lng ?>];
        map.setView(lokasiUMKM, 16);
        L.marker(lokasiUMKM).addTo(map)
          .bindPopup("Lokasi UMKM:<br><strong><?= addslashes($nama); ?></strong>")
          .openPopup();
      <?php else: ?>
        map.fitBounds(geoLayer.getBounds());
      <?php endif; ?>
    })
    .catch(err => console.error("Gagal memuat GeoJSON:", err));

  // ✅ Marker pusat Sumenep

L.marker([-7.015, 113.864], { title: "Pusat Kabupaten" })
  .addTo(map)
  .bindPopup("<strong>Pusat Kabupaten Sumenep</strong>");

  // ✅ Tambahkan semua UMKM sebagai marker
  const semuaUMKM = <?= json_encode($dataMarker); ?>;
  semuaUMKM.forEach(umkm => {
  if (umkm.latitude && umkm.longitude) {
    const iconCustom = getIconBySektor(umkm.sektor);

    L.marker([umkm.latitude, umkm.longitude], {
      icon: iconCustom
    }).addTo(map).bindPopup(`
      <strong>${umkm.nama}</strong><br>
      Sektor: ${umkm.sektor}<br>
      Status: ${umkm.status}
    `);
  }
});
</script>
</body>
</html>
