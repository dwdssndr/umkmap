<?php
include 'koneksi.php';

// Ambil data dari form
$id              = $_POST['id'] ?? '';
$nama            = $_POST['nama'] ?? '';
$nama_pengusaha  = $_POST['nama_pengusaha'] ?? '';
$no_hp           = $_POST['no_hp'] ?? '';
$alamat          = $_POST['alamat'] ?? '';
$kecamatan       = $_POST['kecamatan'] ?? '';
$sektor          = isset($_POST['sektor']) ? implode(',', $_POST['sektor']) : '';
session_start(); // tambahkan jika belum ada
if ($_SESSION['role'] === 'admin') {
  $status = 'Aktif';
} else {
  $status = 'Menunggu';
}
$foto_lama       = $_POST['foto_lama'] ?? '';
$latitude        = $_POST['latitude'] ?? '';
$longitude       = $_POST['longitude'] ?? '';

// Validasi dasar
if (
  empty($id) || empty($nama) || empty($nama_pengusaha) || empty($alamat) ||
  empty($no_hp) || empty($kecamatan) || empty($sektor) || empty($latitude) || empty($longitude)
) {
  echo "<script>alert('Semua field wajib diisi!'); history.back();</script>";
  exit;
}

// Ambil data lama dari database
$stmt_old = $conn->prepare("SELECT * FROM umkm WHERE id = ?");
$stmt_old->bind_param("i", $id);
$stmt_old->execute();
$result_old = $stmt_old->get_result();
$data_lama = $result_old->fetch_assoc();

// Penanganan foto
$foto_raw = $_FILES['foto']['name'] ?? '';
$tmp_foto = $_FILES['foto']['tmp_name'] ?? '';
$foto     = $foto_lama;

if (!empty($foto_raw)) {
  $foto = time() . '_' . preg_replace('/[^a-zA-Z0-9.\-_]/', '', $foto_raw);
  $target = __DIR__ . "/../uploads/" . $foto;

  if (!move_uploaded_file($tmp_foto, $target)) {
    echo "<script>alert('Upload gagal: cek folder atau izin akses'); window.location='editumkm.php?id=$id';</script>";
    exit;
  }
}

// Cek apakah ada perubahan
if (
  $nama === $data_lama['nama'] &&
  $nama_pengusaha === $data_lama['nama_pengusaha'] &&
  $no_hp === $data_lama['no_hp'] &&
  $alamat === $data_lama['alamat'] &&
  $kecamatan === $data_lama['kecamatan'] &&
  $sektor === $data_lama['sektor'] &&
  $status === $data_lama['status'] &&
  $foto === $data_lama['foto'] &&
  $latitude === $data_lama['latitude'] &&
  $longitude === $data_lama['longitude']
) {
  echo "<script>alert('Tidak ada perubahan data'); window.location='editumkm.php?id=$id';</script>";
  exit;
}

// Update database
$stmt = $conn->prepare("UPDATE umkm SET 
  nama = ?, 
  nama_pengusaha = ?, 
  no_hp = ?, 
  alamat = ?, 
  kecamatan = ?, 
  sektor = ?, 
  status = ?, 
  foto = ?, 
  latitude = ?, 
  longitude = ?
  WHERE id = ?");

$stmt->bind_param("ssssssssssi", 
  $nama, $nama_pengusaha, $no_hp, $alamat, 
  $kecamatan, $sektor, $status, $foto, 
  $latitude, $longitude, $id
);

if ($stmt->execute()) {
  echo "<script>alert('Data berhasil diperbarui!'); window.location='dataumkm.php';</script>";
} else {
  echo "<script>alert('Gagal memperbarui data.'); history.back();</script>";
}
?>
