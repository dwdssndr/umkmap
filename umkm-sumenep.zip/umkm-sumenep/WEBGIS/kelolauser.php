<?php
include 'koneksi.php';
session_start();

// Validasi role admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: unauthorized.php");
    exit();
}

$query = "SELECT * FROM user";
$result = $conn->query($query);

// Query semua user
$query = "SELECT * FROM user ORDER BY nama ASC";
$result = $conn->query($query);

// Error handling
if (!$result) {
    echo "Terjadi kesalahan: " . $conn->error;
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <meta charset="UTF-8">
  <title>Kelola Akun Pengguna</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f4f4;
      padding: 50px;
    }
    .container {
      max-width: 1050px;
      margin: auto;
      background-color: #fff;
      padding: 50px;
      box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
      border-radius: 8px;
    }
    h2 {
      text-align: center;
      color: #203A43;
      margin-bottom: 20px;
    }
    .back-button {
      display: inline-block;
      margin-bottom: 15px;
      padding: 8px 12px;
      background-color: #34495e;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
      font-size: 14px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ccc;
      text-align: center;
    }
    th {
      background-color: #203A43;
      color: #fff;
    }
    a.button {
      padding: 5px 10px;
      text-decoration: none;
      color: #fff;
      border-radius: 4px;
      margin: 0 4px;
      font-size: 14px;
    }
    .edit {
      background-color: #3498db;
    }
    .hapus {
      background-color: #e74c3c;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Data Akun User</h2>
     <a href="tambahuser.php" class="button tambah" style="background-color: #2ecc71;">Tambah User</a>

    <table>
      <thead>
        <tr>
          <th>Username</th>
          <th>Nama</th>
          <th>Email</th>
          <th>Telepon</th>
          <th>Password</th>
          <th>Role</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= htmlspecialchars($row['nama']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['telepon']) ?></td>
            <td><?= htmlspecialchars($row['password']) ?></td>
            <td><?= htmlspecialchars($row['role']) ?></td>
           <td>
  <a href="edituser.php?id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">Edit</a>

  <?php if ($row['status'] == 'aktif'): ?>
    <a href="nonaktifkanuser.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Nonaktifkan</a>
  <?php else: ?>
    <a href="aktifkanuser.php?id=<?= $row['id'] ?>" class="btn btn-outline-success btn-sm">Aktifkan</a>
    <a href="hapususer.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus akun ini secara permanen?')">Hapus</a>
  <?php endif; ?>
</td>
</tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <a href="../index.php" class="back-button">Kembali</a>

  </div>

</body>
</html>
