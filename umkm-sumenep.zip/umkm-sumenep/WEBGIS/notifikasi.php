<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['user_id'])) {
  echo "<script>alert('Silakan login terlebih dahulu'); window.location='login.php';</script>";
  exit;
}

$user_id = $_SESSION['user_id'];

// Ambil notifikasi milik user
$stmt = $conn->prepare("SELECT * FROM notifikasi WHERE user_id = ? ORDER BY waktu DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Notifikasi Saya</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .notif-box {
      position: relative;
      padding-right: 35px;
    }
    .close-btn {
      position: absolute;
      top: 10px;
      right: 10px;
      font-size: 18px;
      font-weight: bold;
      color: #e74c3c;
      text-decoration: none;
      cursor: pointer;
    }
    .close-btn:hover {
      color: #c0392b;
    }
  </style>
</head>
<body class="bg-light">
<div class="container py-4">
  <h3 class="mb-4 text-primary">Notifikasi Anda</h3>

  <?php if ($result->num_rows === 0): ?>
    <div class="alert alert-secondary">Belum ada notifikasi.</div>
    <a href="../index.php" class="btn btn-sm btn-secondary mt-3">Kembali</a>
  <?php else: ?>
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="alert alert-<?= ($row['status'] === 'belum dibaca') ? 'warning' : 'secondary' ?> notif-box" id="notif-<?= $row['id'] ?>">
        <span class="close-btn" onclick="hapusNotifikasi(<?= $row['id'] ?>)">×</span>
        <strong><?= date('d-m-Y H:i', strtotime($row['waktu'])) ?>:</strong><br>
        <?= htmlspecialchars($row['pesan']) ?>
      </div>
    <?php endwhile; ?>
  <?php endif; ?>
</div>
</div>

<script>
function hapusNotifikasi(id) {
  fetch("hapusnotif.php?id=" + id)
    .then(response => response.text())
    .then(data => {
      if (data.trim() === "success") {
        const box = document.getElementById("notif-" + id);
        if (box) box.remove();
      } else {
        alert("Gagal menghapus notifikasi.");
      }
    })
    .catch(error => {
      console.error("Error:", error);
      alert("Terjadi kesalahan saat menghapus.");
    });
}
</script>
</body>
</html>

<?php
// Tandai semua notifikasi sebagai dibaca
$conn->query("UPDATE notifikasi SET status = 'dibaca' WHERE user_id = $user_id");
?>
