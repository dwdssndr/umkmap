<?php
include 'koneksi.php';

$username = $_POST['username'];
$nama     = $_POST['nama'];
$email    = $_POST['email'];
$telepon  = $_POST['telepon'];
$alamat   = $_POST['alamat'];
$password = $_POST['password'];
$role     = 'user'; // default user role

// Handle upload foto
$foto_name = '';
if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
    $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
    $allowed = ['jpg', 'jpeg', 'png'];
    if (in_array(strtolower($ext), $allowed)) {
        $foto_name = uniqid() . '-' . $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], 'uploads/' . $foto_name);
    }
}

// Validasi username dan email
$cek = mysqli_query($conn, "SELECT * FROM user WHERE username='$username' OR email='$email'");
if (mysqli_num_rows($cek) > 0) {
    echo "<script>alert('Username atau Email sudah terdaftar!');history.back();</script>";
} else {
    $query = "INSERT INTO user (username, nama, email, telepon, alamat, foto, password, role)
              VALUES ('$username', '$nama', '$email', '$telepon', '$alamat', '$foto_name', '$password', '$role')";

    $simpan = mysqli_query($conn, $query);

    if ($simpan) {
        echo "<script>
          alert('Pendaftaran berhasil!');
          window.location.href = 'login.php';
        </script>";
    } else {
        echo "<script>alert('Gagal menyimpan data!');history.back();</script>";
    }
}
?>
