<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login UMKM Sumenep</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #f0f2f5, #dfe6ed);
      font-family: 'Inter', sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }
    .login-card {
      background-color: #ffffff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 12px 32px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 420px;
      transition: all 0.3s ease;
    }
    .login-card:hover {
      box-shadow: 0 16px 40px rgba(0,0,0,0.12);
    }
    .login-title {
      font-size: 1.6rem;
      font-weight: 600;
      margin-bottom: 30px;
      text-align: center;
      color: #212529;
    }
    .form-label {
      font-weight: 500;
      color: #495057;
    }
    .form-control {
      border-radius: 8px;
      transition: border-color 0.2s ease;
    }
    .form-control:focus {
      border-color: #007bff;
      box-shadow: none;
    }
    .btn-login {
      background-color: #007bff;
      border: none;
      font-weight: 500;
      border-radius: 8px;
      transition: background-color 0.2s ease;
    }
    .btn-login:hover {
      background-color: #0056b3;
    }
    .brand {
      text-align: center;
      margin-bottom: 20px;
    }
    .brand img {
      height: 60px;
    }
    .footer {
      text-align: center;
      font-size: 0.85rem;
      color: #6c757d;
      margin-top: 20px;
    }
  </style>
</head>
<body>

  <div class="login-card">
       <div class="login-title">Login Sistem UMKM Sumenep</div>
   <form method="POST" action="proses_login.php">
  <div class="mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" name="username" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" name="email" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="password" class="form-label">Password</label>
    <input type="password" name="password" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-login w-100 mt-3">Masuk</button>
</form>


<div class="text-center mt-3">
  Belum punya akun? <a href="daftaruser.php" class="text-decoration-none text-primary fw-semibold">Daftar di sini</a>
</div>



    <div class="footer">
      &copy; <?= date('Y'); ?> UMKM Sumenep. All rights reserved.
    </div>
  </div>

</body>
</html>
