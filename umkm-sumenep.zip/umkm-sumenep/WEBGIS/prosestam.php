<?php
session_start();
include 'koneksi.php';

// Validasi login pengguna
if (!isset($_SESSION['username'])) {
  echo "<script>alert('Silakan login terlebih dahulu'); window.location='login.php';</script>";
  exit;
}

$username = $_SESSION['username'];

// Ambil ID pengguna berdasarkan username
$stmtUser = $conn->prepare("SELECT id FROM user WHERE username = ?");
$stmtUser->bind_param("s", $username);
$stmtUser->execute();
$resUser = $stmtUser->get_result();

if ($resUser->num_rows !== 1) {
  echo "<script>alert('User tidak ditemukan'); window.location='tambahumkm.php';</script>";
  exit;
}

$user = $resUser->fetch_assoc();
$user_id = $user['id'];

// Ambil data dari form input
$nama_umkm      = $_POST['nama_umkm'] ?? '';
$nama_pengusaha = $_POST['nama_pengusaha'] ?? '';
$no_hp          = $_POST['no_hp'] ?? '';
$alamat         = $_POST['alamat'] ?? '';
$kecamatan      = $_POST['kecamatan'] ?? '';
$sektorArray    = $_POST['sektor'] ?? [];
$sektor         = implode(', ', $sektorArray); // Gabungkan sektor menjadi string
$latitude       = $_POST['latitude'] ?? '';
$longitude      = $_POST['longitude'] ?? '';

// Proses unggah foto
$foto_raw = $_FILES['foto']['name'] ?? '';
$tmp_foto = $_FILES['foto']['tmp_name'] ?? '';
$foto     = time() . '_' . preg_replace('/[^a-zA-Z0-9.\-_]/', '', $foto_raw); // Sanitasi nama file
$target   = "../uploads/" . $foto;

// Validasi koordinat
if (!is_numeric($latitude) || !is_numeric($longitude)) {
  echo "<script>alert('Latitude dan Longitude harus berupa angka'); window.location='tambahumkm.php';</script>";
  exit;
}

// Proses penyimpanan foto jika ada
if (!empty($foto_raw)) {
  if (!move_uploaded_file($tmp_foto, $target)) {
    echo "<script>alert('Gagal mengunggah foto'); window.location='tambahumkm.php';</script>";
    exit;
  }
} else {
  $foto = ''; // Kosongkan jika tidak ada foto diunggah
}

// Simpan data UMKM ke database
$status = 'aktif'; // Status default untuk input dari admin
$stmt = $conn->prepare("INSERT INTO umkm (user_id, nama, nama_pengusaha, no_hp, alamat, kecamatan, sektor, latitude, longitude, foto, status)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssssssss", $user_id, $nama_umkm, $nama_pengusaha, $no_hp, $alamat, $kecamatan, $sektor, $latitude, $longitude, $foto, $status);

// Eksekusi dan berikan umpan balik
if ($stmt->execute()) {
  echo "<script>alert('UMKM berhasil ditambahkan'); window.location='dataumkm.php';</script>";
} else {
  echo "<script>alert('Gagal menambahkan UMKM'); window.location='tambahumkm.php';</script>";
}
?>
