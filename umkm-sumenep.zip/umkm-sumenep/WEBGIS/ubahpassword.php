<?php
session_start();
include 'koneksi.php';

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
  echo "<script>alert('Silakan login terlebih dahulu.'); window.location='login.php';</script>";
  exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Ubah Password</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card shadow-sm">
          <div class="card-header bg-primary text-white text-center">
            <h5 class="mb-0">Ubah Password</h5>
          </div>
          <div class="card-body">
            <form action="prosesubahpass.php" method="POST">
              <div class="mb-3">
                <label for="password_lama" class="form-label">Password Lama</label>
                <input type="password" name="password_lama" id="password_lama" class="form-control" required>
              </div>

              <div class="mb-3">
                <label for="password_baru" class="form-label">Password Baru</label>
                <input type="password" name="password_baru" id="password_baru" class="form-control" required>
              </div>

              <div class="mb-3">
                <label for="konfirmasi" class="form-label">Konfirmasi Password Baru</label>
                <input type="password" name="konfirmasi" id="konfirmasi" class="form-control" required>
              </div>

              <div class="d-flex justify-content-between mt-4">
                <a href="../index.php" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-success">Simpan Password</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
