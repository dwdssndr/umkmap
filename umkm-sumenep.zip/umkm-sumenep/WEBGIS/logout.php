<?php
session_start();
session_unset(); // hapus semua variabel sesi
session_destroy(); // akhiri sesi

// Redirect ke halaman login
header("Location: ../index.php");
exit;
?>
