<?php
include 'koneksi.php';
session_start();

// Validasi role admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: unauthorized.php");
    exit();
}

// Jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama   = trim($_POST['nama']);
    $email  = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Enkripsi
    $role   = $_POST['role'];

    // Validasi sederhana
    if (empty($nama) || empty($email) || empty($_POST['password']) || empty($role)) {
        $error = "Semua field harus diisi.";
    } else {
        // Simpan ke DB
        $query = "INSERT INTO user (nama, email, password, role) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $nama, $email, $password, $role);
        
        if ($stmt->execute()) {
            header("Location: kelolauser.php");
            exit();
        } else {
            $error = "Gagal menambah user: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah User Baru</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f0f0f0;
      padding: 30px;
    }
    .container {
      max-width: 600px;
      margin: auto;
      background-color: #fff;
      padding: 25px;
      border-radius: 8px;
      box-shadow: 0px 0px 8px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 20px;
    }
    label {
      font-weight: bold;
      display: block;
      margin: 10px 0 5px;
    }
    input, select {
      width: 100%;
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
    }
    .submit-btn {
      margin-top: 20px;
      padding: 10px;
      background-color: #2ecc71;
      color: #fff;
      border: none;
      border-radius: 4px;
      width: 100%;
      font-size: 16px;
    }
    .error {
      color: red;
      margin-bottom: 10px;
      text-align: center;
    }
    .back-btn {
      display: block;
      margin-top: 15px;
      text-align: center;
      color: #34495e;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Tambah User Baru</h2>
    
    <?php if (isset($error)): ?>
      <div class="error"><?= $error ?></div>
    <?php endif; ?>
    
    <form method="POST">
      <label for="nama">Nama</label>
      <input type="text" name="nama" required>

      <label for="email">Email</label>
      <input type="email" name="email" required>

      <label for="password">Password</label>
      <input type="password" name="password" required>

      <label for="role">Role</label>
      <select name="role" required>
        <option value="">-- Pilih Role --</option>
        <option value="admin">Admin</option>
        <option value="user">User</option>
      </select>

      <button type="submit" class="submit-btn">Simpan User</button>
    </form>

        <a href="kelolauser.php" class="btn btn-sm btn-secondary mt-3">Kembali</a>
  </div>
</body>
</html>
