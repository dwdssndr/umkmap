<?php
session_start();
include 'koneksi.php'; // koneksi ke database sig_umkm

$username     = $_POST['username'];
$email    = $_POST['email'];
$password = $_POST['password'];

// Validasi input
if (empty($username) || empty($email) || empty($password)) {
  echo "<script>alert('Semua field harus diisi'); window.location.href='login.php';</script>";
  exit;
}

$query = "SELECT id, username, email, role FROM user WHERE username = ? AND password = ?";

// Query ke tabel user
$query = "SELECT * FROM user WHERE username = ? AND email = ?";
$stmt  = $conn->prepare($query);
$stmt->bind_param("ss", $username, $email);

if (!$stmt) {
  die("Query gagal disiapkan: " . $conn->error);
}

$stmt->bind_param("ss", $username, $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();

  // Verifikasi password
 if ($user['password'] === $password) {
    $_SESSION['username'] = $user['username'];
    $_SESSION['nama'] = $user['nama'];
    $_SESSION['role']     = $user['role'];
    $_SESSION['user_id']  = $user['id']; // 🟢 Ini wajib biar tampil UMKM milik sendiri
    // Redirect ke halaman utama
    header("Location: ../index.php");
    exit;
  } else {
    echo "<script>alert('Password salah'); window.location.href='login.php';</script>";
  }
} else {
  echo "<script>alert('Akun tidak ditemukan'); window.location.href='login.php';</script>";
}
?>
