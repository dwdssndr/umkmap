<?php
include 'koneksi.php';
session_start();

// Validasi role admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: unauthorized.php");
    exit();
}

// Validasi parameter ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Update status jadi nonaktif
    $update = $conn->query("UPDATE user SET status = 'nonaktif' WHERE id = $id");

    if ($update) {
        header("Location: kelolauser.php?msg=akun_dinonaktifkan");
        exit();
    } else {
        echo "Gagal menonaktifkan akun: " . $conn->error;
    }
} else {
    echo "ID tidak ditemukan.";
}
?>
