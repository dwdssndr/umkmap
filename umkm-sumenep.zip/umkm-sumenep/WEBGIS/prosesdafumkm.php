<?php
session_start();
include 'koneksi.php';
include 'email.php';

// 🛡️ Validasi login
if (!isset($_SESSION['username'])) {
  echo "<script>alert('Silakan login terlebih dahulu'); window.location='login.php';</script>";
  exit;
}

$username = $_SESSION['username'];
$role     = $_SESSION['role'] ?? 'user';

// 🔍 Ambil data user
$stmtUser = $conn->prepare("SELECT id, email, telepon, nama FROM user WHERE username = ?");
$stmtUser->bind_param("s", $username);
$stmtUser->execute();
$resUser = $stmtUser->get_result();

if ($resUser->num_rows !== 1) {
  echo "<script>alert('User tidak ditemukan'); window.location.href='daftarumkm.php';</script>";
  exit;
}

$user         = $resUser->fetch_assoc();
$user_id      = $user['id'];
$emailUser    = $user['email'];
$nomorWA      = str_replace("0", "+62", $user['telepon']);
$namaPemilik  = $user['nama'];

// 🧾 Ambil data dari form
$nama             = $_POST['nama'] ?? '';
$nama_pengusaha   = $_POST['nama_pengusaha'] ?? '';
$no_hp            = $_POST['no_hp'] ?? '';
$alamat           = $_POST['alamat'] ?? '';
$kecamatan        = $_POST['kecamatan'] ?? '';
$sektorArray      = $_POST['sektor'] ?? [];
$sektor           = implode(', ', $sektorArray);
$latitude         = $_POST['latitude'] ?? '';
$longitude        = $_POST['longitude'] ?? '';

// 🖼️ Proses foto (jika ada)
$foto_raw = $_FILES['foto']['name'] ?? '';
$tmp_foto = $_FILES['foto']['tmp_name'] ?? '';
$foto     = '';

if (!empty($foto_raw)) {
  $foto = time() . '_' . preg_replace('/[^a-zA-Z0-9.\-_]/', '', $foto_raw);
  $target = "../uploads/" . $foto;

  // Validasi tipe dan ukuran
  $allowedTypes = ['image/jpeg', 'image/png'];
  $maxSize = 2 * 1024 * 1024;

  if (!in_array($_FILES['foto']['type'], $allowedTypes) || $_FILES['foto']['size'] > $maxSize) {
    echo "<script>alert('Format gambar tidak valid atau ukuran terlalu besar'); window.location='daftarumkm.php';</script>";
    exit;
  }

  // ✅ Pindahkan file ke folder uploads
  if (!move_uploaded_file($tmp_foto, $target)) {
    echo "<script>alert('Gagal mengunggah foto'); window.location='daftarumkm.php';</script>";
    exit;
  }
}

// 💡 Tentukan status
$status = ($role === 'admin') ? 'aktif' : 'menunggu';

// 🛡️ Validasi input wajib
if (
  empty($nama) || empty($alamat) || empty($kecamatan) || empty($sektor) ||
  !is_numeric($latitude) || !is_numeric($longitude)
) {
  echo "<script>alert('Harap isi semua data dengan benar'); window.location='daftarumkm.php';</script>";
  exit;
}

// 🔎 Cek duplikat
$cekDuplikat = $conn->prepare("SELECT id FROM umkm WHERE nama = ? AND user_id = ?");
$cekDuplikat->bind_param("si", $nama, $user_id);
$cekDuplikat->execute();
$resDuplikat = $cekDuplikat->get_result();

if ($resDuplikat->num_rows > 0) {
  echo "<script>alert('UMKM dengan nama yang sama sudah terdaftar'); window.location='daftarumkm.php';</script>";
  exit;
}

// 💾 Simpan ke database
$query = "INSERT INTO umkm (user_id, nama, nama_pengusaha, no_hp, alamat, kecamatan, sektor, latitude, longitude, foto, status)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("issssssssss", $user_id, $nama, $nama_pengusaha, $no_hp, $alamat, $kecamatan, $sektor, $latitude, $longitude, $foto, $status);

if ($stmt->execute()) {
  $umkm_id = $stmt->insert_id;

  // 🔔 Kirim notifikasi ke admin
  $notifPesan = "UMKM '$nama' membutuhkan validasi.";
  $notifStatus = 'belum dibaca';
  $notifWaktu  = date('Y-m-d H:i:s');

  $stmtAdmin = $conn->prepare("SELECT id FROM user WHERE role = 'admin'");
  $stmtAdmin->execute();
  $resAdmin = $stmtAdmin->get_result();

  while ($admin = $resAdmin->fetch_assoc()) {
    $admin_id = $admin['id'];

    $stmtNotif = $conn->prepare("INSERT INTO notifikasi (user_id, pesan, status, waktu) VALUES (?, ?, ?, ?)");
    $stmtNotif->bind_param("isss", $admin_id, $notifPesan, $notifStatus, $notifWaktu);
    $stmtNotif->execute();
  }

  // ✅ Kirim email jika langsung aktif
  if ($status === 'aktif') {
    kirimNotifikasi($emailUser, $namaPemilik, $nama, $status);
  }
  echo "<script>alert('UMKM berhasil didaftarkan'); window.location.href='dataumkm.php';</script>";
} else {
  echo "<script>alert('Gagal menyimpan data UMKM'); window.location.href='daftarumkm.php';</script>";
}
?>
