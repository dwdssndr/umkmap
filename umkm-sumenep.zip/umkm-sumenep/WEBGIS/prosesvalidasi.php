<?php
session_start();
include 'koneksi.php';
include 'fungsiwa.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Validasi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo "<script>alert('Halaman khusus admin'); window.location='login.php';</script>";
  exit;
}

$id   = $_GET['id'] ?? '';
$aksi = $_GET['aksi'] ?? '';

// Validasi parameter
if (!ctype_digit($id) || !in_array($aksi, ['aktif', 'tolak'])) {
  echo "<script>alert('Parameter tidak valid'); window.location='../dataumkm.php';</script>";
  exit;
}

$statusBaru = ($aksi === 'aktif') ? 'aktif' : 'ditolak';

// Update status UMKM
$stmt = $conn->prepare("UPDATE umkm SET status = ? WHERE id = ?");
$stmt->bind_param("si", $statusBaru, $id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
  // Ambil data user & UMKM
  $q = $conn->prepare("SELECT u.id AS user_id, u.email, u.nama AS namaUser, u.telepon, umkm.nama AS namaUMKM
                       FROM umkm JOIN user u ON umkm.user_id = u.id WHERE umkm.id = ?");
  $q->bind_param("i", $id);
  $q->execute();
  $res = $q->get_result();

  if ($res->num_rows > 0) {
    $data       = $res->fetch_assoc();
    $to         = $data['email'];
    $user_id    = $data['user_id'];
    $namaUser   = $data['namaUser'];
    $namaUMKM   = $data['namaUMKM'];
    $telepon    = $data['telepon'];

    // Format notifikasi
    if ($aksi === 'aktif') {
      $pesanNotif = "UMKM <strong>'$namaUMKM'</strong> milik Anda telah berhasil divalidasi dan aktif di sistem.";
      $bodyEmail  = "Halo $namaUser,\n\nUMKM Anda '$namaUMKM' telah berhasil divalidasi dan kini tampil di sistem UMKMap Sumenep.\n\nTerima kasih telah berkontribusi!";
    } else {
      $pesanNotif = "UMKM <strong>'$namaUMKM'</strong> Anda ditolak. Silakan revisi dan ajukan ulang.";
      $bodyEmail  = "Halo $namaUser,\n\nMohon maaf, UMKM Anda '$namaUMKM' belum lolos proses validasi.\nSilakan cek kembali data dan ajukan ulang jika diperlukan.\n\nSalam.";
    }

    // Kirim Email
    $mail = new PHPMailer(true);
    try {
      $mail->isSMTP();
      $mail->Host       = 'smtp.gmail.com';
      $mail->SMTPAuth   = true;
      $mail->Username   = 'dwidesisuandari@gmail.com';
      $mail->Password   = 'msuy oran sfxx ovox'; // App password Gmail
      $mail->SMTPSecure = 'tls';
      $mail->Port       = 587;

      $mail->setFrom('dwidesisuandari@gmail.com', 'UMKMap Sumenep');
      $mail->addAddress($to, $namaUser);
      $mail->Subject = "Status Validasi UMKM Anda: " . strtoupper($statusBaru);
      $mail->Body    = $bodyEmail;
      $mail->send();
    } catch (Exception $e) {
      error_log("Gagal kirim email: {$mail->ErrorInfo}");
    }
 echo "<script>alert('Berhasil'); window.location.href='dataumkm.php';</script>";
    // Simpan Notifikasi Internal
    $stmtNotif = $conn->prepare("INSERT INTO notifikasi (user_id, pesan) VALUES (?, ?)");
    $stmtNotif->bind_param("is", $user_id, $pesanNotif);
    $stmtNotif->execute();

 // 📲 Kirim WhatsApp untuk status apapun (aktif atau ditolak)
$nomorWA = preg_replace('/^0/', '62', $telepon);

if (preg_match('/^62\d{9,13}$/', $nomorWA)) {
  if ($statusBaru === 'aktif') {
    $pesanWA = "Halo $namaUser! UMKM '$namaUMKM' Anda telah divalidasi dan kini aktif di sistem GIS UMKM Sumenep. Terima kasih atas kontribusinya!";
  } elseif ($statusBaru === 'ditolak') {
    $pesanWA = "Halo $namaUser! Mohon maaf, UMKM '$namaUMKM' Anda belum lolos validasi. Silakan perbaiki data dan ajukan ulang ya";
  }

  if (!empty($pesanWA)) {
    $waStatus = kirimNotifikasiWA($nomorWA, $pesanWA);

    if ($waStatus['status'] === 'ok') {
      file_put_contents('log_raw_wa.txt', json_encode($waStatus) . "\n", FILE_APPEND);

      $stmtUpdateWA = $conn->prepare("UPDATE umkm SET wa_sent = 'yes' WHERE id = ?");
      $stmtUpdateWA->bind_param("i", $id);
      $stmtUpdateWA->execute();
    } else {
      error_log("Gagal kirim WA ke $nomorWA | Response: " . json_encode($waStatus));
    }
  }
} else {
  error_log("Format nomor WA tidak valid: $nomorWA");
}
 }
}
?>
