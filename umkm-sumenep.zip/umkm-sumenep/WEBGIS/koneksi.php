<?php
$host     = 'localhost';           // Tetap pakai 'localhost' untuk XAMPP
$username = 'root';                // Username default XAMPP biasanya 'root'
$password = '';                    // Password default biasanya kosong ('') di XAMPP
$database = 'sig_umkm';            // Nama database yang sudah kamu buat di phpMyAdmin

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
} 
?>
